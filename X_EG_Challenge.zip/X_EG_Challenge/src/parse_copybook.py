from lexicon import *

def parse_cobol_copybook(file: str, target_dir: str, dep_dir = EMPTY_STRING):
    pass

if __name__ == "__main__":
    parse_cobol_copybook("copybooks/EIB.cpy", "converted/")