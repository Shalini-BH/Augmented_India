<!DOCTYPE html>
<html>
<head>
<title>CodeCraft - Unleash Your Creativity</title>
<style>
body {
  font-family: 'Arial', sans-serif;
  background-color: #01204c;
  margin: 0;
  padding: 0;
  color: #333;
}

.container {
  max-width: 800px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  margin-bottom: 30px;
  color: #333;
}

label {
  display: block;
  margin-bottom: 8px;
}

input[type="file"],
select {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
}

button {
  background-color: #004AAD;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  width: 15%;
}

button:hover {
  background-color: #4cae4c;
}

.slogan {
  text-align: center;
  font-style: italic;
  margin: 20px 0;
  color: #777;
}

/* Add any desired styling for the button */
#download-button {
  padding: 10px 20px;
  background-color: #4CAF50; /* Green */
  color: white;
  font-size: 16px;
  border: none;
  cursor: pointer;
}
</style>
</head>
<body>

<div class="container">
  <h1>Augmented India</h1> 

  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">

    <label for="codeFile">Choose Your Code File:</label>
    <input type="file" name="codeFile" id="codeFile">
    <button type="submit" name="upload">UPLOAD</button><br><br>

    <label for="inputLang">Input Language:</label>
    <select name="inputLang" id="inputLang">
      <option value="cobol">Cobol</option> 
    </select>

    <label for="outputLang">Output Format:</label>
    <select name="outputLang" id="outputLang">
      <option value="python">Python Output</option>
      <!-- <option value="java">Java Output</option> -->
    </select>

    <button type="submit" name="convert">Convert</button>
    <br><br>

  </form>

  <?php
  if(isset($_POST['convert'])){
      // Execute the Python script
      exec("python C:/xampp/htdocs/X_EG_Challenge/src/main.py 2> error.log", $output, $return_code);


      if($return_code === 0) {
          echo "<p>Conversion successful.</p>";

          // Move the converted file to the 'converted' folder
          $destination_folder = "C:/xampp/htdocs/X_EG_Challenge/converted/";

          // Check if the destination folder exists, if not create it
          if (!file_exists($destination_folder)) {
              mkdir($destination_folder, 0777, true);
          }


          // Display downloadable files from the 'converted' folder
          $files = scandir($destination_folder);
          if($files !== false && count($files) > 2) { // Check if directory is not empty (excluding . and ..)
              echo "<h2>Files Available for Download:</h2>";
              echo "<ul>";
              foreach($files as $file) {
                  if($file != "." && $file != "..") { // Exclude . and ..
                      $file_path = $destination_folder . $file;
                      if(file_exists($file_path)) {
                          echo "<li><a href='converted/$file' download>$file</a></li>";
                      } else {
                          echo "<li>Error: File $file is not available for download.</li>";
                      }
                  }
              }
              echo "</ul>";
          } else {
              echo "<p>No files available for download.</p>";
          }
      } else {
          echo "<p>Conversion failed.</p>";
      }
  }
  ?>
</div>

<?php
if(isset($_POST['upload'])){
    $upload_dir = "C:/xampp/htdocs/X_EG_Challenge/input/";
    $upload_file = $upload_dir . basename($_FILES["codeFile"]["name"]);
    
    if (move_uploaded_file($_FILES["codeFile"]["tmp_name"], $upload_file)) {
        echo "<p>File is valid, and was successfully uploaded.</p>";
    } else {
        echo "<p>Upload failed.</p>";
    }
}
?>
</body>
</html>
